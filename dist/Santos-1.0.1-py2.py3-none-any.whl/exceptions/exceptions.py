__author__ = 'anderson'
# -*- coding: utf-8 -*-

class TaskException(Exception):
    pass
